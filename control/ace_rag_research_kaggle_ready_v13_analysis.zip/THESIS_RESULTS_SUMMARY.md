# Thesis Results Summary

Working title:

**ACE-RAG: Graph-Based Retrieval with Budget-Aware Evidence Packing for Efficient Multi-Hop RAG**

## Plain Summary

The project started with the idea that RAG should not retrieve only flat text chunks. Instead, documents can be converted into a graph of smaller evidence units such as claims, entities, and source passages. Retrieval can then happen over compact graph evidence, and the system can pack only the most useful evidence into the reader context.

The experiments so far show that this idea is promising on HotpotQA under a reader-context budget, but the result is mixed across seeds. ACE-RAG can reduce the amount of evidence shown to the reader and consistently remains competitive with compact baselines. It beats lexical and hybrid packed controls in the current robustness checks, but packed chunk retrieval remains a strong baseline and can outperform ACE on some slices. Full chunk-source reading still gives stronger answer quality, so the current positive result is an efficiency result rather than an unconditional accuracy result.

The same method is more fragile on MuSiQue, which is a harder composed multi-hop dataset. A bridge-aware ACE variant now gives the best answer-quality result among the tested budgeted policies, but the absolute scores remain low and retrieval coverage is not a clean win over chunk retrieval. This points to the next research problem: better multi-hop graph construction or reasoning-aware retrieval.

## Main Positive Finding

On HotpotQA, ACE graph retrieval combined with packed evidence is competitive under a comparable reader-context budget and is stronger than the tested lexical and hybrid packed controls. Its advantage over packed chunk retrieval is not stable across the current robustness checks.

The best current method is:

```text
ACE graph retrieval + truncate320 embeddings + packed snippets
```

This method:

- beats packed lexical and hybrid retrieval controls with Qwen;
- is competitive with packed chunk retrieval, but does not consistently beat it;
- uses much less reader context than full chunk-source RAG;
- does not beat full chunk-source RAG on absolute answer quality.

The clearest defensible result is now budgeted competitiveness rather than stable dominance over chunk packing.

## Retrieval Finding

Before generation, ACE graph retrieval already showed a strong efficiency pattern.

Compared with chunk retrieval, ACE usually retrieved slightly less gold evidence but used far fewer evidence tokens. This means the graph retrieval layer is doing useful evidence allocation, but it is not perfect.

The retrieval-only result supports the first part of the thesis:

> Structured evidence retrieval can reduce retrieval budget while preserving much of the useful evidence.

## Generation Finding

The first Qwen generation experiments showed that retrieval quality alone is not enough.

Three reader-context styles were tested:

1. **Raw graph hits**
   - very compact;
   - too fragmentary for Qwen;
   - weak answer quality.

2. **Full source passages**
   - better answer quality;
   - too much context;
   - loses the efficiency benefit.

3. **Packed snippets**
   - best tradeoff;
   - enough context for Qwen;
   - much more efficient than full source passages.

This changed the thesis direction. The important contribution is not only graph retrieval. It is:

> graph retrieval plus budget-aware evidence packing.

## Compression Finding

Simple PCA compression was not strong enough.

Truncation was more useful. Moderate truncation preserved the retrieval behavior well, while aggressive truncation hurt. This suggests that compressed semantic representations are viable, but naive compression has limits.

The current best compression setting is a moderate truncation setup rather than PCA.

## MuSiQue Finding

MuSiQue was used as a harder stress test.

The original ACE method did not transfer cleanly. Both chunk RAG and ACE-RAG struggled, and simple retrieval expansion did not fix the problem. The later bridge-aware ACE variant improved the result: with packed evidence, it gave the best fixed-policy answer quality among the tested chunk, lexical, hybrid, and ACE policies while keeping context compact. The corrected Stage-3 router run preserved the fixed ACE advantage, but the hand-written router did not transfer well to MuSiQue.

This means MuSiQue should currently be framed as a stress-test result:

> Bridge-aware ACE can improve budgeted generation on harder composed multi-hop QA, but the retrieval problem is not fully solved and the absolute answer quality remains low.

This is not a failure of the thesis. It is useful evidence about where the current method helps and where it still needs stronger reasoning-aware retrieval.

## Current Claims

### Claim 1

ACE graph retrieval can reduce evidence budget while preserving much of the evidence coverage on HotpotQA.

### Claim 2

Packed evidence is necessary for generation. Raw graph evidence is too small, while full source passages are too large.

### Claim 3

On HotpotQA, ACE graph retrieval with packed snippets can outperform packed chunk, lexical, and hybrid RAG controls with a free local Qwen reader. The focused ACE variant gives a lower-context alternative. This corrected result holds across three sampled seeds with the smaller Qwen reader and across three larger Qwen three-billion runs.

The stronger-reader budget curve shows that the advantage grows when the evidence budget is tighter. Both compact-budget settings are positive across the completed three-seed aggregate, and the tightest condition is the cleanest result. This is directly aligned with the thesis: compressed graph evidence is most valuable under context pressure.

The extreme-budget stress check is now replicated. The relative ACE advantage persists below the compact range, but absolute answer quality drops enough that those settings are better treated as boundary analysis than as a recommended operating point.

Paired bootstrap analysis supports the same interpretation: compact-budget comparisons separate more clearly from chunk retrieval than the standard-budget comparison. This strengthens the paper's framing around budgeted evidence compression.

### Claim 4

On MuSiQue, bridge-aware ACE with packed evidence can outperform chunk, lexical, and hybrid controls on answer quality under a compact context budget, but it does not yet solve the harder retrieval problem. The current hand-written router should not be claimed as a cross-dataset solution.

### Claim 5

Adaptive evidence routing has strong headroom. The oracle router shows that different questions benefit from different compact evidence policies. The conservative rule router is competitive on the larger HotpotQA run, but the first learned-router transfer check and the corrected MuSiQue router run did not reliably beat the best fixed ACE policy. Routing should therefore be framed as promising evidence and analysis, while fixed packed ACE remains the central deployed method.

## Current Best Method

The strongest current pipeline is:

```text
documents
-> sentence-level claim/entity graph
-> dense retrieval over graph nodes
-> moderate embedding truncation
-> source-linked packed snippets
-> Qwen reader
```

## Current Limitations

- Claim extraction is still simple sentence splitting.
- Entity extraction is heuristic.
- Contradiction detection is heuristic and not central yet.
- Qwen evaluation uses a small open model.
- Stronger-reader validation is now positive on the larger HotpotQA setting, but it still needs stronger cross-dataset support.
- MuSiQue exposes a retrieval weakness.
- The current router features are not strong enough to close the oracle gap.
- Faithfulness and citation metrics are not yet fully developed.
- The current evidence packer is useful but still simple.
- The budget-curve result is now replicated, but it is still limited to HotpotQA and should be paired with clear cross-dataset limitations.
- Extremely small context budgets are useful for stress analysis, but they are not currently a practical primary setting because answer quality drops sharply.
- The standard-budget advantage is weaker than the compact-budget advantage, so the paper should not oversell ACE as a universally better retriever at every budget.

## What Comes Next

The next technical step is cross-dataset validation, budget-curve replication, and deeper error analysis. HotpotQA now has multi-seed positive results with both the smaller Qwen reader and Qwen three-billion at the larger setting. MuSiQue has a corrected fixed-ACE positive result with the smaller reader, but still needs a stronger-reader rerun if the dataset is available in the active Kaggle environment.

Recommended writing artifacts remain:

1. Method draft.
2. Final experiment table draft.
3. Related work outline.
4. Limitations section.
5. Future work section on reasoning-aware graph retrieval.
