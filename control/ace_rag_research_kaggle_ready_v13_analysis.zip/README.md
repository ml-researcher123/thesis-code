# ACE-RAG Research Scaffold

Working title:

**ACE-RAG: Adaptive Compressed Evidence Graphs for Faithful and Efficient Retrieval-Augmented Generation**

This folder contains the first experimental scaffold for testing the core claim:

> RAG systems can become more faithful and efficient when retrieval operates over compressed, typed evidence graphs instead of flat text chunks.

The code is intentionally split into a small offline MVP and optional heavier backends for real benchmark runs.

## What Is Implemented

- Offline toy dataset with multi-hop and conflicting evidence examples.
- Dataset loaders for:
  - `toy`
  - `hotpotqa` through Hugging Face `hotpot_qa`
  - `musique_local` from local JSON/JSONL exports
  - `ragbench` through Hugging Face `rungalileo/ragbench`
- Evidence graph construction:
  - passage nodes
  - claim nodes
  - entity nodes
  - `derived_from`, `mentions`, and lightweight `contradicts` edges
- Baselines:
  - flat chunk retrieval
  - ACE graph retrieval
  - ACE graph retrieval without conflict expansion
- Compression hooks:
  - identity
  - truncation
  - PCA
  - binary sign compression
- Evaluation:
  - retrieval recall@k
  - all-gold retrieved@k
  - extractive answer EM/F1
  - lightweight verifier answer/conflict/abstain rates

## Folder Layout

```text
ace_rag_research/
  ace_rag/
    datasets.py          # toy, HotpotQA, MuSiQue-local, RAGBench loaders
    graph_builder.py     # passage/claim/entity graph construction
    embeddings.py        # lexical and sentence-transformers backends
    compression.py       # identity/truncate/PCA/binary compressors
    retriever.py         # chunk baseline and ACE graph retriever
    verifier.py          # lightweight support/conflict verifier
    generator.py         # offline extractive reader and optional OpenAI reader
    metrics.py           # retrieval and answer metrics
    schema.py            # shared dataclasses
  experiments/
    run_mvp.py           # main baseline-vs-ACE experiment
    run_ablation.py      # small ablation grid
  configs/
    toy.yaml
    hotpotqa.yaml
    musique_local.yaml
    ragbench.yaml
  scripts/
    prepare_datasets.py
  data/
    raw/
    processed/
  results/
```

## Setup

For Kaggle/Colab, use [CLOUD_RUN.md](CLOUD_RUN.md). For Kaggle specifically, start with [ACE_RAG_Kaggle_Runbook.ipynb](notebooks/ACE_RAG_Kaggle_Runbook.ipynb).

Research progress is tracked in [RESEARCH_LOG.md](RESEARCH_LOG.md). The stable project summary is in [PROJECT_BRIEF.md](PROJECT_BRIEF.md).

Minimal offline smoke test:

```bash
cd ace_rag_research
python -m experiments.run_mvp --dataset toy --embedder lexical --compressor identity
```

The same run through a config file:

```bash
python -m experiments.run_mvp --config configs\toy.yaml
```

Full research dependencies:

```bash
cd ace_rag_research
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

HotpotQA slice:

```bash
python -m experiments.run_mvp ^
  --dataset hotpotqa ^
  --split validation ^
  --limit 300 ^
  --embedder sentence-transformers ^
  --embedding-model BAAI/bge-small-en-v1.5 ^
  --compressor pca ^
  --compress-dims 128
```

Free Qwen reader evaluation:

```bash
python -m experiments.run_qwen_eval \
  --dataset hotpotqa \
  --limit 50 \
  --methods chunk,ace_graph \
  --compressor truncate \
  --compress-dims 320 \
  --reader-model Qwen/Qwen2.5-1.5B-Instruct \
  --reader-device cuda \
  --reader-batch-size 4 \
  --reader-context sources \
  --out-dir cloud_results
```

Snippet-context Qwen evaluation:

```bash
python -m experiments.run_qwen_eval \
  --dataset hotpotqa \
  --limit 200 \
  --methods chunk,ace_graph \
  --compressor truncate \
  --compress-dims 320 \
  --reader-model Qwen/Qwen2.5-1.5B-Instruct \
  --reader-device cuda \
  --reader-batch-size 4 \
  --reader-context snippets \
  --snippet-window 1 \
  --max-snippets 8 \
  --max-snippet-tokens 80 \
  --out-dir cloud_results
```

Autonomous Stage-2 pipeline:

```bash
python -m experiments.run_stage2_autonomous \
  --dataset hotpotqa \
  --limit 200 \
  --compressor truncate \
  --compress-dims 320 \
  --packed-budgets 160,220,280,340 \
  --focused-budgets 220,280 \
  --reader-model Qwen/Qwen2.5-1.5B-Instruct \
  --reader-device cuda \
  --reader-batch-size 4 \
  --out-dir cloud_results
```

MuSiQue local export:

```bash
python -m experiments.run_mvp ^
  --dataset musique_local ^
  --musique-path data\raw\musique.jsonl ^
  --limit 300 ^
  --embedder sentence-transformers ^
  --compressor pca
```

RAGBench slice:

```bash
python -m experiments.run_mvp ^
  --dataset ragbench ^
  --split test ^
  --limit 300 ^
  --embedder sentence-transformers ^
  --compressor pca
```

## Method Roadmap

The current MVP uses deterministic sentence claims and simple entity extraction. The paper-grade system should replace or extend these components:

1. **Claim extraction**
   - Current: sentence-level claims.
   - Next: LLM or IE model extracts atomic claims with entity/date/source spans.

2. **Contradiction detection**
   - Current: cheap negation plus lexical-overlap heuristic.
   - Next: NLI model or verifier LLM creates calibrated `supports`/`contradicts` edges.

3. **Compression**
   - Current: identity/truncate/PCA/binary hooks.
   - Next: train/evaluate multi-resolution embeddings, quantization, or Matryoshka-style subspaces.

4. **Adaptive retrieval**
   - Current: retrieve claim/entity nodes, expand to passages, optionally expand contradictions.
   - Next: stop/expand based on uncertainty, conflict, token budget, and evidence coverage.

5. **Generation**
   - Current: offline extractive answer proxy.
   - Next: cited generation with OpenAI/local LLM and faithfulness evaluation.

## First Paper Table

The first publishable table should compare:

| Method | Recall@5 | All-Gold@5 | Citation Support | Conflict Accuracy | Tokens | Latency | Memory |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| BM25 RAG | | | | | | | |
| Dense Chunk RAG | | | | | | | |
| Graph RAG, no compression | | | | | | | |
| Compression only | | | | | | | |
| ACE-RAG | | | | | | | |

The strongest early go/no-go criterion:

> ACE-RAG must improve all-gold retrieval and/or faithfulness while reducing retrieved token budget versus dense chunk RAG.

## Bridge-Aware MuSiQue Commands

Retrieval-only check:

```bash
python -m experiments.run_mvp \
  --dataset musique_local \
  --musique-path data/raw/musique.jsonl \
  --limit 300 \
  --embedder sentence-transformers \
  --embedding-model BAAI/bge-small-en-v1.5 \
  --device cuda \
  --compressor truncate \
  --compress-dims 320 \
  --top-k-nodes 48 \
  --max-expanded-docs 5 \
  --ace-retriever bridge \
  --bridge-seed-nodes 12 \
  --bridge-terms 10 \
  --bridge-weight 0.35 \
  --methods chunk,ace_graph \
  --no-save-runs \
  --out-dir cloud_results_musique_bridge
```

Stage-2 Qwen check:

```bash
python -m experiments.run_stage2_autonomous \
  --dataset musique_local \
  --musique-path data/raw/musique.jsonl \
  --limit 200 \
  --embed-device cuda \
  --compressor truncate \
  --compress-dims 320 \
  --top-k-nodes 48 \
  --max-expanded-docs 5 \
  --ace-retriever bridge \
  --bridge-seed-nodes 12 \
  --bridge-terms 10 \
  --bridge-weight 0.35 \
  --reader-model Qwen/Qwen2.5-1.5B-Instruct \
  --reader-device cuda \
  --reader-batch-size 4 \
  --packed-budgets 280 \
  --focused-budgets 280 \
  --snippet-window 1 \
  --max-snippets 8 \
  --max-snippet-tokens 80 \
  --out-dir cloud_results_musique_bridge
```

## Primary Benchmark Anchors

- HotpotQA: multi-hop QA with supporting facts.
- MuSiQue: harder composed multi-hop QA.
- RAGBench: explainable RAG evaluation labels.
- Later: RAMDocs/CONFACT-style conflicting evidence benchmarks.
