# Current Smoke-Test Results

Command:

```bash
python -m experiments.run_mvp --config configs\toy.yaml
```

Output file:

```text
results/toy_lexical_identity_dims128_nodes8_docs5_metrics.csv
```

## Toy Dataset Result

| Method | Recall@5 | All-Gold@5 | Avg Evidence Tokens | Avg Expanded Docs | Verifier Conflict Rate |
| --- | ---: | ---: | ---: | ---: | ---: |
| Chunk RAG | 1.0000 | 1.0000 | 85.00 | 5.00 | 0.25 |
| ACE Graph | 1.0000 | 1.0000 | 53.25 | 3.50 | 0.25 |
| ACE Graph, No Conflict Expansion | 1.0000 | 1.0000 | 53.25 | 3.50 | 0.25 |

Interpretation:

The offline toy run confirms the harness is working and shows the desired first signal: ACE graph retrieval preserves gold-document coverage while reducing retrieved evidence tokens. This is not a research result yet; the next meaningful test is HotpotQA/MuSiQue with dense embeddings and PCA or binary compression.

## HotpotQA Stage-1 Result

Best current 1000-example HotpotQA result:

| Method | Recall@5 | All-Gold@5 | Extractive F1 | Avg Evidence Tokens |
| --- | ---: | ---: | ---: | ---: |
| Chunk RAG | 0.8560 | 0.7230 | 0.0499 | 408.94 |
| ACE Graph, Identity | 0.8310 | 0.6840 | 0.0845 | 136.63 |

Interpretation:

ACE graph retrieval preserves most evidence coverage while using about one-third of the retrieved evidence tokens. This is the strongest early signal so far.

Important tuning results:

| Config | Recall@5 | All-Gold@5 | Extractive F1 | Avg Evidence Tokens |
| --- | ---: | ---: | ---: | ---: |
| ACE identity, nodes=48, docs=5 | 0.8310 | 0.6840 | 0.0845 | 136.63 |
| ACE identity, nodes=48, docs=6 | 0.8310 | 0.6840 | 0.0861 | 166.25 |
| ACE identity, nodes=64, docs=5 | 0.8310 | 0.6840 | 0.0845 | 136.68 |
| ACE truncate384, nodes=48, docs=5 | 0.8310 | 0.6840 | 0.0845 | 136.68 |
| ACE truncate256, nodes=48, docs=5 | 0.8165 | 0.6610 | 0.0826 | 136.29 |

Current best setting remains:

```text
compressor=identity
top_k_nodes=48
max_expanded_docs=5
```

Next compression tests:

```text
truncate:320
truncate:128
```

## Qwen Stage-2 Reader Results

HotpotQA limit-200 with `Qwen/Qwen2.5-1.5B-Instruct`:

| Reader Context | Method | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | ---: | ---: | ---: |
| full sources | Chunk RAG | 0.1600 | 0.2619 | 402.20 |
| full sources | ACE Graph | 0.1400 | 0.2385 | 419.90 |
| snippets | Chunk RAG | 0.1400 | 0.2509 | 377.13 |
| snippets | ACE Graph | 0.1200 | 0.2329 | 346.35 |

Interpretation:

Snippet context is better than raw graph-hit context for Qwen. It preserves much of the source-passage answer quality while reducing reader tokens, but it does not yet restore the strong token-efficiency advantage seen in retrieval-only experiments.

## Autonomous Stage-2 Packed Evidence

HotpotQA limit-200 with `Qwen/Qwen2.5-1.5B-Instruct`:

| Policy | Method | Context | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | --- | ---: | ---: | ---: |
| chunk_sources | Chunk RAG | sources | 0.1600 | 0.2619 | 402.20 |
| chunk_packed_280 | Chunk RAG | packed snippets | 0.1250 | 0.2337 | 268.31 |
| ace_sources | ACE Graph | sources | 0.1400 | 0.2385 | 419.90 |
| ace_packed_160 | ACE Graph | packed snippets | 0.1350 | 0.2227 | 150.24 |
| ace_packed_220 | ACE Graph | packed snippets | 0.1450 | 0.2440 | 208.94 |
| ace_packed_280 | ACE Graph | packed snippets | 0.1300 | 0.2530 | 266.75 |
| ace_packed_340 | ACE Graph | packed snippets | 0.1100 | 0.2375 | 318.31 |

Interpretation:

`ace_packed_280` is the strongest Stage-2 policy so far. It comes close to the full chunk-source reader while using substantially less reader context, and it beats the packed chunk control at nearly the same budget. This supports the emerging claim that graph retrieval plus budget-aware evidence packing is stronger than retrieval alone.

HotpotQA limit-500 follow-up:

| Policy | Method | Context | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | --- | ---: | ---: | ---: |
| chunk_sources | Chunk RAG | sources | 0.1560 | 0.2677 | 408.11 |
| chunk_packed_280 | Chunk RAG | packed snippets | 0.1560 | 0.2720 | 268.69 |
| ace_sources | ACE Graph | sources | 0.1340 | 0.2494 | 424.91 |
| ace_packed_220 | ACE Graph | packed snippets | 0.1480 | 0.2233 | 209.69 |
| ace_packed_280 | ACE Graph | packed snippets | 0.1460 | 0.2449 | 267.53 |
| ace_focused_220 | ACE Graph | focused packed | 0.1580 | 0.2509 | 209.10 |
| ace_focused_280 | ACE Graph | focused packed | 0.1340 | 0.2358 | 266.16 |

Interpretation:

The limit-500 result showed that naive ACE packed snippets were weaker than the packed chunk control. The focused packer improved ACE substantially at a lower budget and became the strongest ACE generation-stage policy so far. However, the packed chunk control remains a strong baseline and must be retained in future experiments.

HotpotQA limit-1000 follow-up:

| Policy | Method | Context | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | --- | ---: | ---: | ---: |
| chunk_sources | Chunk RAG | sources | 0.1350 | 0.2460 | 408.90 |
| chunk_packed_280 | Chunk RAG | packed snippets | 0.1390 | 0.2395 | 269.19 |
| ace_sources | ACE Graph | sources | 0.1220 | 0.2382 | 418.02 |
| ace_packed_280 | ACE Graph | packed snippets | 0.1440 | 0.2543 | 267.88 |
| ace_focused_220 | ACE Graph | focused packed | 0.1320 | 0.2249 | 208.66 |

Interpretation:

The limit-1000 result is the strongest end-to-end result so far. `ace_packed_280` outperforms both the full chunk-source reader and the packed chunk control while using much less reader context than full chunk sources. This makes ACE graph retrieval plus packed evidence the current best method direction.

HotpotQA seed-validation result:

| Policy | Method | Context | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | --- | ---: | ---: | ---: |
| chunk_sources | Chunk RAG | sources | 0.1350 | 0.2460 | 408.90 |
| chunk_packed_280 | Chunk RAG | packed snippets | 0.1390 | 0.2395 | 269.19 |
| ace_sources | ACE Graph | sources | 0.1220 | 0.2382 | 418.02 |
| ace_packed_280 | ACE Graph | packed snippets | 0.1440 | 0.2543 | 267.88 |
| ace_focused_220 | ACE Graph | focused packed | 0.1320 | 0.2249 | 208.66 |

Interpretation:

The seed-validation table preserves the same main conclusion: `ace_packed_280` is the strongest tested policy and uses substantially less reader context than full chunk-source RAG.

HotpotQA baseline-rich validation:

| Policy | Method | Context | Recall@5 | All-Gold@5 | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| chunk_sources | Chunk RAG | sources | 0.8545 | 0.7210 | 0.1380 | 0.2463 | 403.17 |
| chunk_packed_280 | Chunk RAG | packed snippets | 0.8545 | 0.7210 | 0.1100 | 0.2012 | 269.52 |
| bm25_sources | BM25 RAG | sources | 0.6370 | 0.3620 | 0.1240 | 0.2140 | 409.17 |
| bm25_packed_280 | BM25 RAG | packed snippets | 0.6370 | 0.3620 | 0.0970 | 0.1844 | 268.98 |
| hybrid_sources | Hybrid RAG | sources | 0.7890 | 0.5980 | 0.1280 | 0.2195 | 402.41 |
| hybrid_packed_280 | Hybrid RAG | packed snippets | 0.7890 | 0.5980 | 0.1010 | 0.1913 | 268.72 |
| ace_sources | ACE Graph | sources | 0.8245 | 0.6680 | 0.1120 | 0.2060 | 415.92 |
| ace_packed_280 | ACE Graph | packed snippets | 0.8245 | 0.6680 | 0.1150 | 0.2151 | 267.46 |
| ace_focused_220 | ACE Graph | focused packed | 0.8245 | 0.6680 | 0.1290 | 0.2105 | 208.71 |

Interpretation:

The stronger baseline run narrows the claim. Full chunk-source RAG remains the strongest answer-quality setting, but it uses substantially more reader context. Under a comparable packed context budget, `ace_packed_280` outperforms packed chunk, packed BM25, and packed hybrid controls while using slightly less reader context. ACE retrieval also beats the hybrid baseline on evidence coverage, though it does not beat chunk retrieval coverage. This supports a budget-constrained RAG claim rather than an unconditional accuracy claim.

HotpotQA seed-7 robustness validation:

| Policy | Method | Context | Recall@5 | All-Gold@5 | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| chunk_sources | Chunk RAG | sources | 0.8625 | 0.7410 | 0.1450 | 0.2475 | 400.38 |
| chunk_packed_280 | Chunk RAG | packed snippets | 0.8625 | 0.7410 | 0.1390 | 0.2381 | 269.45 |
| bm25_sources | BM25 RAG | sources | 0.6390 | 0.3720 | 0.1150 | 0.2095 | 406.18 |
| bm25_packed_280 | BM25 RAG | packed snippets | 0.6390 | 0.3720 | 0.1080 | 0.1948 | 268.78 |
| hybrid_sources | Hybrid RAG | sources | 0.7945 | 0.6120 | 0.1320 | 0.2385 | 397.37 |
| hybrid_packed_280 | Hybrid RAG | packed snippets | 0.7945 | 0.6120 | 0.1110 | 0.2123 | 267.83 |
| ace_sources | ACE Graph | sources | 0.8115 | 0.6530 | 0.1280 | 0.2411 | 405.98 |
| ace_packed_280 | ACE Graph | packed snippets | 0.8115 | 0.6530 | 0.1350 | 0.2320 | 267.18 |
| ace_focused_220 | ACE Graph | focused packed | 0.8115 | 0.6530 | 0.1330 | 0.2111 | 208.34 |

Interpretation:

The seed-7 run makes the HotpotQA result mixed rather than a clean replication. `ace_packed_280` remains stronger than packed BM25 and packed hybrid controls, and it uses slightly less context than packed chunk, but packed chunk has higher Qwen F1 on this seed. Full source chunk remains the strongest absolute answer-quality policy. The safer HotpotQA claim is that ACE is a competitive compact-evidence method with wins against lexical and hybrid packed controls, while chunk packing remains a strong baseline that must be reported honestly.

HotpotQA additional robustness validation:

| Policy | Method | Context | Recall@5 | All-Gold@5 | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| chunk_sources | Chunk RAG | sources | 0.8530 | 0.7190 | 0.1290 | 0.2468 | 399.61 |
| chunk_packed_280 | Chunk RAG | packed snippets | 0.8530 | 0.7190 | 0.1260 | 0.2384 | 269.51 |
| bm25_sources | BM25 RAG | sources | 0.6455 | 0.3840 | 0.1040 | 0.2055 | 403.09 |
| bm25_packed_280 | BM25 RAG | packed snippets | 0.6455 | 0.3840 | 0.1190 | 0.2109 | 269.50 |
| hybrid_sources | Hybrid RAG | sources | 0.8095 | 0.6340 | 0.1300 | 0.2336 | 398.20 |
| hybrid_packed_280 | Hybrid RAG | packed snippets | 0.8095 | 0.6340 | 0.1250 | 0.2160 | 268.46 |
| ace_sources | ACE Graph | sources | 0.8110 | 0.6470 | 0.1200 | 0.2217 | 414.26 |
| ace_packed_280 | ACE Graph | packed snippets | 0.8110 | 0.6470 | 0.1230 | 0.2221 | 267.15 |
| ace_focused_220 | ACE Graph | focused packed | 0.8110 | 0.6470 | 0.1350 | 0.2250 | 208.60 |

Interpretation:

This additional HotpotQA seed confirms the mixed robustness pattern. Chunk packing remains the strongest packed baseline on answer F1, while ACE remains better than packed BM25 and packed hybrid. The focused ACE policy is the best ACE setting on this slice and uses much less context than packed chunk, but it still does not beat packed chunk on F1. This reinforces the need for an adaptive router rather than a fixed ACE policy.

## MuSiQue Stage Results

MuSiQue retrieval-only limit-300:

| Method | Recall@5 | All-Gold@5 | Avg Evidence Tokens |
| --- | ---: | ---: | ---: |
| Chunk RAG | 0.5450 | 0.2333 | 399.27 |
| ACE Graph | 0.5017 | 0.1700 | 142.72 |

MuSiQue Stage-2 limit-200 with `Qwen/Qwen2.5-1.5B-Instruct`:

| Policy | Method | Context | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | --- | ---: | ---: | ---: |
| chunk_sources | Chunk RAG | sources | 0.0350 | 0.0895 | 375.35 |
| chunk_packed_280 | Chunk RAG | packed snippets | 0.0150 | 0.0829 | 260.39 |
| ace_sources | ACE Graph | sources | 0.0350 | 0.0821 | 374.92 |
| ace_packed_220 | ACE Graph | packed snippets | 0.0050 | 0.0770 | 205.03 |
| ace_packed_280 | ACE Graph | packed snippets | 0.0100 | 0.0766 | 259.86 |
| ace_focused_220 | ACE Graph | focused packed | 0.0100 | 0.0740 | 203.53 |
| ace_focused_280 | ACE Graph | focused packed | 0.0100 | 0.0977 | 255.91 |

Interpretation:

MuSiQue is much harder than HotpotQA. The first MuSiQue result does not cleanly reproduce the HotpotQA ACE win. The best ACE policy is focused packed evidence at a moderate budget, but the bigger issue is retrieval coverage. The next MuSiQue experiment should test slightly larger ACE retrieval expansion rather than additional reader packing variants.

MuSiQue expanded ACE retrieval test:

| Policy | Method | Context | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | --- | ---: | ---: | ---: |
| chunk_sources | Chunk RAG | sources | 0.0350 | 0.0895 | 375.35 |
| chunk_packed_280 | Chunk RAG | packed snippets | 0.0150 | 0.0829 | 260.39 |
| ace_sources | ACE Graph | sources | 0.0300 | 0.0824 | 612.34 |
| ace_packed_280 | ACE Graph | packed snippets | 0.0050 | 0.0623 | 268.30 |
| ace_focused_280 | ACE Graph | focused packed | 0.0250 | 0.0750 | 266.22 |

Interpretation:

The expanded ACE retrieval setting did not improve MuSiQue. It increased source context substantially and degraded packed-evidence results. This suggests the current ACE graph method should not be further tuned on MuSiQue without a stronger multi-hop retrieval design.

MuSiQue bridge-aware ACE Stage-2:

| Policy | Method | Context | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | --- | ---: | ---: | ---: |
| chunk_sources | Chunk RAG | sources | 0.0350 | 0.0895 | 375.35 |
| chunk_packed_280 | Chunk RAG | packed snippets | 0.0150 | 0.0829 | 260.39 |
| ace_bridge_sources | ACE Bridge | sources | 0.0300 | 0.0789 | 388.38 |
| ace_bridge_packed_280 | ACE Bridge | packed snippets | 0.0150 | 0.0943 | 256.24 |
| ace_bridge_focused_280 | ACE Bridge | focused packed | 0.0150 | 0.0982 | 250.41 |

Interpretation:

Bridge-aware ACE gives the strongest MuSiQue result so far, but only modestly. It improves over the standard MuSiQue ACE setting and beats the chunk baselines on Qwen F1 while using less reader context than chunk sources. The absolute scores remain low, so MuSiQue should still be framed as a hard stress test and motivation for stronger reasoning-aware graph retrieval.

MuSiQue bridge-aware ACE limit-500 validation:

| Policy | Method | Context | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | --- | ---: | ---: | ---: |
| chunk_sources | Chunk RAG | sources | 0.0320 | 0.0893 | 412.44 |
| chunk_packed_280 | Chunk RAG | packed snippets | 0.0260 | 0.0752 | 256.02 |
| ace_bridge_sources | ACE Bridge | sources | 0.0360 | 0.0990 | 428.30 |
| ace_bridge_packed_280 | ACE Bridge | packed snippets | 0.0360 | 0.0993 | 252.74 |
| ace_bridge_focused_280 | ACE Bridge | focused packed | 0.0220 | 0.0832 | 246.21 |

Interpretation:

The limit-500 bridge validation keeps the weak-positive MuSiQue pattern. `ace_bridge_packed_280` is the best policy by Qwen F1 and uses much less context than chunk sources. Retrieval coverage is still lower than chunk retrieval, so the result should be framed carefully: bridge-aware ACE helps generation under a context budget, but the harder multi-hop retrieval problem is not fully solved.

MuSiQue baseline-rich bridge validation:

| Policy | Method | Context | Recall@5 | All-Gold@5 | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| chunk_sources | Chunk RAG | sources | 0.5060 | 0.1840 | 0.0320 | 0.0893 | 412.44 |
| chunk_packed_280 | Chunk RAG | packed snippets | 0.5060 | 0.1840 | 0.0260 | 0.0752 | 256.02 |
| bm25_sources | BM25 RAG | sources | 0.3830 | 0.0800 | 0.0240 | 0.0607 | 406.99 |
| bm25_packed_280 | BM25 RAG | packed snippets | 0.3830 | 0.0800 | 0.0160 | 0.0532 | 256.49 |
| hybrid_sources | Hybrid RAG | sources | 0.4990 | 0.1620 | 0.0380 | 0.0873 | 403.70 |
| hybrid_packed_280 | Hybrid RAG | packed snippets | 0.4990 | 0.1620 | 0.0360 | 0.0820 | 255.67 |
| ace_bridge_sources | ACE Bridge | sources | 0.4810 | 0.1800 | 0.0340 | 0.0982 | 427.86 |
| ace_bridge_packed_280 | ACE Bridge | packed snippets | 0.4810 | 0.1800 | 0.0400 | 0.1065 | 251.49 |
| ace_bridge_focused_280 | ACE Bridge | focused packed | 0.4810 | 0.1800 | 0.0240 | 0.0836 | 245.23 |

Interpretation:

This is the strongest MuSiQue result so far. `ace_bridge_packed_280` gives the best Qwen EM and F1 among chunk, BM25, hybrid, and ACE policies while using less reader context than packed chunk and packed hybrid. Retrieval coverage is still not a clean win: chunk retrieval has slightly better recall and all-gold coverage, while ACE bridge is close on all-gold coverage and stronger at turning retrieved evidence into answers. The defensible claim is that bridge-aware ACE improves budgeted generation on MuSiQue, not that it solves MuSiQue retrieval.

## HotpotQA Stage-3 Adaptive Router

Stage-3 HotpotQA validation with fixed compact policies, a rule router, and an oracle router.
These numbers supersede the earlier Stage-3 reader run because the earlier run used right-padding with a decoder-only Qwen model, which produced unreliable batched generation.

| Policy | Router Type | Recall@5 | All-Gold@5 | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| chunk_packed_280 | fixed | 0.8545 | 0.7210 | 0.3130 | 0.4157 | 269.52 |
| bm25_packed_280 | fixed | 0.6370 | 0.3620 | 0.2620 | 0.3616 | 268.98 |
| hybrid_packed_280 | fixed | 0.7890 | 0.5980 | 0.2760 | 0.3833 | 268.72 |
| ace_packed_280 | fixed | 0.8245 | 0.6680 | 0.3110 | 0.4131 | 267.46 |
| ace_focused_220 | fixed | 0.8245 | 0.6680 | 0.3240 | 0.4374 | 208.71 |
| router_rule | rule | 0.8225 | 0.6580 | 0.3220 | 0.4350 | 236.87 |
| router_oracle | oracle | 0.8200 | 0.6580 | 0.4630 | 0.5960 | 221.50 |

Interpretation:

The corrected reader run gives a much stronger HotpotQA result. Focused ACE beats compact chunk retrieval on answer quality while using substantially less context. The conservative rule router nearly matches the best fixed ACE result, but it does not yet beat it. The oracle router remains the strongest diagnostic signal: per-question policy choice has large headroom. The next publishable step is cross-seed validation and then a calibrated or learned router trained on the exported routing features.

## HotpotQA Stage-3 Seed-7 Robustness

The same corrected Stage-3 setup was rerun on a different HotpotQA sample.

| Policy | Router Type | Recall@5 | All-Gold@5 | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| chunk_packed_280 | fixed | 0.8625 | 0.7410 | 0.3260 | 0.4335 | 269.45 |
| bm25_packed_280 | fixed | 0.6390 | 0.3720 | 0.2850 | 0.3832 | 268.78 |
| hybrid_packed_280 | fixed | 0.7945 | 0.6120 | 0.3020 | 0.4002 | 267.83 |
| ace_packed_280 | fixed | 0.8115 | 0.6530 | 0.3420 | 0.4496 | 267.18 |
| ace_focused_220 | fixed | 0.8115 | 0.6530 | 0.3310 | 0.4240 | 208.34 |
| router_rule | rule | 0.8275 | 0.6750 | 0.3300 | 0.4324 | 235.74 |
| router_oracle | oracle | 0.8080 | 0.6470 | 0.4940 | 0.6136 | 222.31 |

Interpretation:

The corrected HotpotQA result is robust across these two seeds. ACE packed is the best compact fixed policy on seed seven, and focused ACE remains a strong lower-context variant. The rule router is not yet better than the best fixed policy, but oracle routing again shows large headroom. This supports the next method step: learn or calibrate the router rather than hand-tuning it.

## HotpotQA Stage-3 Seed-13 Robustness

The corrected Stage-3 setup was rerun on a third HotpotQA sample.

| Policy | Router Type | Recall@5 | All-Gold@5 | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| chunk_packed_280 | fixed | 0.8570 | 0.7340 | 0.3320 | 0.4297 | 268.00 |
| bm25_packed_280 | fixed | 0.6365 | 0.3870 | 0.2660 | 0.3628 | 268.29 |
| hybrid_packed_280 | fixed | 0.7985 | 0.6170 | 0.3070 | 0.4060 | 268.10 |
| ace_packed_280 | fixed | 0.8225 | 0.6740 | 0.3340 | 0.4377 | 267.25 |
| ace_focused_220 | fixed | 0.8225 | 0.6740 | 0.3280 | 0.4306 | 208.45 |
| router_rule | rule | 0.8300 | 0.6830 | 0.3470 | 0.4444 | 235.16 |
| router_oracle | oracle | 0.8150 | 0.6590 | 0.4790 | 0.5995 | 220.62 |

Interpretation:

Seed thirteen strengthens the adaptive-router story: the conservative rule router is the best non-oracle policy on answer quality while using less context than the fixed packed policies. The fixed ACE policies remain strong, and oracle routing again shows substantial headroom.

## HotpotQA Stage-3 Three-Seed Aggregate

Corrected Stage-3 aggregate over three HotpotQA samples:

| Policy | Mean Qwen EM | Mean Qwen F1 | Mean Reader Tokens | Mean Recall@5 | Mean All-Gold@5 |
| --- | ---: | ---: | ---: | ---: | ---: |
| chunk_packed_280 | 0.3237 | 0.4263 | 268.99 | 0.8580 | 0.7320 |
| bm25_packed_280 | 0.2710 | 0.3692 | 268.68 | 0.6375 | 0.3737 |
| hybrid_packed_280 | 0.2950 | 0.3965 | 268.22 | 0.7940 | 0.6090 |
| ace_packed_280 | 0.3290 | 0.4335 | 267.30 | 0.8195 | 0.6650 |
| ace_focused_220 | 0.3277 | 0.4307 | 208.50 | 0.8195 | 0.6650 |
| router_rule | 0.3330 | 0.4373 | 235.92 | 0.8267 | 0.6720 |
| router_oracle | 0.4787 | 0.6030 | 221.48 | 0.8143 | 0.6547 |

Interpretation:

Across three corrected HotpotQA runs, the rule router has the best mean answer quality among deployable policies, and focused ACE gives the best compact fixed-policy efficiency. The retrieval metrics still favor chunk retrieval on raw gold-document coverage, but answer quality favors ACE-style compact evidence. This is the strongest HotpotQA evidence so far.

## Offline Router Transfer

The exported router feature files were used for offline transfer tests without rerunning retrieval or Qwen.

Train on corrected seed forty-two features, test on corrected seed seven:

| Policy | Type | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | ---: | ---: | ---: |
| ace_packed_280 | fixed | 0.3420 | 0.4496 | 267.18 |
| ace_focused_220 | fixed | 0.3310 | 0.4240 | 208.34 |
| router_rule | rule | 0.3300 | 0.4324 | 235.74 |
| router_learned_f1_tree | learned | 0.3340 | 0.4268 | 207.83 |
| router_oracle | oracle | 0.4940 | 0.6136 | 222.31 |

Train on corrected seed seven features, test on corrected seed forty-two:

| Policy | Type | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | ---: | ---: | ---: |
| ace_focused_220 | fixed | 0.3240 | 0.4374 | 208.71 |
| ace_packed_280 | fixed | 0.3110 | 0.4131 | 267.46 |
| router_rule | rule | 0.3220 | 0.4350 | 236.87 |
| router_learned_f1_tree | learned | 0.3230 | 0.4372 | 208.37 |
| router_oracle | oracle | 0.4630 | 0.5960 | 221.50 |

Interpretation:

The current learned router does not transfer beyond the best fixed ACE policy. It mostly learns to choose focused ACE, which is efficient but not enough to close the oracle gap. This is an important negative result: the router needs stronger deploy-time features, not just a better classifier over the current retrieval-confidence features.

## MuSiQue Corrected Stage-3 Router

Corrected Stage-3 MuSiQue bridge run with the decoder-safe Qwen reader:

| Policy | Router Type | Recall@5 | All-Gold@5 | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| chunk_packed_280 | fixed | 0.4896 | 0.3000 | 0.0350 | 0.1034 | 269.25 |
| bm25_packed_280 | fixed | 0.3367 | 0.1800 | 0.0100 | 0.0523 | 266.06 |
| hybrid_packed_280 | fixed | 0.4688 | 0.2700 | 0.0500 | 0.1001 | 267.77 |
| ace_bridge_packed_280 | fixed | 0.4550 | 0.2800 | 0.0600 | 0.1188 | 265.24 |
| ace_bridge_focused_280 | fixed | 0.4550 | 0.2800 | 0.0550 | 0.1180 | 262.77 |
| router_rule | rule | 0.4446 | 0.2600 | 0.0400 | 0.1049 | 266.46 |
| router_oracle | oracle | 0.4062 | 0.2450 | 0.1150 | 0.2154 | 252.95 |

Interpretation:

Bridge-aware ACE remains the best fixed compact MuSiQue policy under the corrected Qwen reader, despite lower raw recall than chunk retrieval. The hand-written router is not strong enough on MuSiQue because it selects chunk-style evidence too often. The oracle result is still much higher, so adaptive routing has headroom, but manual threshold tuning is not the right path. A small offline sweep over current retrieval-confidence features did not find a simple rule that improves MuSiQue without hurting HotpotQA seeds. The next controlled experiment is a stronger open Qwen reader with retrieval and routing held fixed.

## HotpotQA Qwen 3B Validation

Kaggle Stage-3 HotpotQA validation with `Qwen/Qwen2.5-3B-Instruct`, seed 42, limit 500:

| Policy | Router Type | Recall@5 | All-Gold@5 | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| chunk_packed_280 | fixed | 0.8740 | 0.7580 | 0.3240 | 0.4194 | 269.28 |
| bm25_packed_280 | fixed | 0.6580 | 0.3960 | 0.2480 | 0.3394 | 269.15 |
| hybrid_packed_280 | fixed | 0.8080 | 0.6280 | 0.2860 | 0.3792 | 268.61 |
| ace_packed_280 | fixed | 0.8590 | 0.7260 | 0.3460 | 0.4489 | 266.50 |
| ace_focused_220 | fixed | 0.8590 | 0.7260 | 0.3420 | 0.4452 | 208.95 |
| router_rule | rule | 0.8420 | 0.6920 | 0.3320 | 0.4267 | 235.59 |
| router_oracle | oracle | 0.8380 | 0.6920 | 0.4860 | 0.6085 | 222.37 |

Interpretation:

The stronger Qwen reader improves the HotpotQA story. `ace_packed_280` is the best deployable policy on answer quality, and `ace_focused_220` is almost tied while using much less evidence context. Chunk retrieval still has stronger raw retrieval coverage, but ACE turns a slightly lower retrieval set into better answers. The rule router is not yet reliable enough to beat fixed ACE, while the oracle result again shows large per-question routing headroom.

## HotpotQA Qwen 3B Three-Seed Aggregate

Kaggle Stage-3 HotpotQA validation with `Qwen/Qwen2.5-3B-Instruct`, limit 500, seeds 42, 7, and 13:

| Policy | Mean Qwen EM | Mean Qwen F1 | Mean Reader Tokens | Mean Recall@5 | Mean All-Gold@5 |
| --- | ---: | ---: | ---: | ---: | ---: |
| chunk_packed_280 | 0.3227 | 0.4270 | 268.90 | 0.8750 | 0.7613 |
| bm25_packed_280 | 0.2680 | 0.3677 | 268.78 | 0.6533 | 0.4013 |
| hybrid_packed_280 | 0.3080 | 0.4081 | 268.16 | 0.8080 | 0.6327 |
| ace_packed_280 | 0.3413 | 0.4447 | 266.91 | 0.8427 | 0.7047 |
| ace_focused_220 | 0.3360 | 0.4438 | 208.51 | 0.8427 | 0.7047 |
| router_rule | 0.3213 | 0.4293 | 235.01 | 0.8367 | 0.6900 |
| router_oracle | 0.4793 | 0.6077 | 220.79 | 0.8337 | 0.6900 |

Interpretation:

The stronger-reader HotpotQA result now holds across multiple sampled runs. Fixed ACE packed evidence gives the best average deployable answer quality, while focused ACE is almost tied at a much lower context budget. Chunk retrieval has the highest raw gold-document coverage, but lower answer quality, which supports the central argument that graph-structured compressed evidence can be more useful to the reader than simply maximizing document coverage. The hand-written router remains weaker than fixed ACE on average, so it should not be the headline method.

## HotpotQA Qwen 3B Limit-1000 Scaling

Kaggle Stage-3 HotpotQA validation with `Qwen/Qwen2.5-3B-Instruct`, seed 42, limit 1000:

| Policy | Router Type | Recall@5 | All-Gold@5 | Qwen EM | Qwen F1 | Avg Reader Evidence Tokens |
| --- | --- | ---: | ---: | ---: | ---: | ---: |
| chunk_packed_280 | fixed | 0.8545 | 0.7210 | 0.3080 | 0.4123 | 269.52 |
| bm25_packed_280 | fixed | 0.6370 | 0.3620 | 0.2540 | 0.3502 | 268.98 |
| hybrid_packed_280 | fixed | 0.7890 | 0.5980 | 0.2810 | 0.3820 | 268.72 |
| ace_packed_280 | fixed | 0.8245 | 0.6680 | 0.3300 | 0.4338 | 267.46 |
| ace_focused_220 | fixed | 0.8245 | 0.6680 | 0.3120 | 0.4170 | 208.71 |
| router_rule | rule | 0.8225 | 0.6580 | 0.3060 | 0.4150 | 236.87 |
| router_oracle | oracle | 0.8170 | 0.6520 | 0.4730 | 0.5972 | 223.16 |

Interpretation:

The larger Qwen three-billion run preserves the main fixed-ACE result. `ace_packed_280` gives the strongest deployable answer quality while using a similar context budget to packed chunk retrieval. Focused ACE is still more efficient than packed ACE, but at this larger sample size it is better framed as a lower-budget tradeoff rather than the best-quality variant. The router remains below fixed packed ACE, while the oracle continues to show substantial routing headroom.

## HotpotQA Qwen 3B Limit-1000 Partial Aggregate

Kaggle Stage-3 HotpotQA validation with `Qwen/Qwen2.5-3B-Instruct`, limit 1000, seeds 42 and 7:

| Policy | Mean Qwen EM | Mean Qwen F1 | Mean Reader Tokens | Mean Recall@5 | Mean All-Gold@5 |
| --- | ---: | ---: | ---: | ---: | ---: |
| chunk_packed_280 | 0.3185 | 0.4218 | 269.49 | 0.8585 | 0.7310 |
| bm25_packed_280 | 0.2675 | 0.3631 | 268.88 | 0.6380 | 0.3670 |
| hybrid_packed_280 | 0.2955 | 0.3956 | 268.27 | 0.7917 | 0.6050 |
| ace_packed_280 | 0.3380 | 0.4390 | 267.32 | 0.8180 | 0.6605 |
| ace_focused_220 | 0.3245 | 0.4225 | 208.53 | 0.8180 | 0.6605 |
| router_rule | 0.3190 | 0.4237 | 236.31 | 0.8250 | 0.6665 |
| router_oracle | 0.4870 | 0.6041 | 222.39 | 0.8155 | 0.6520 |

Interpretation:

The larger Qwen three-billion result has replicated across the first two larger samples. `ace_packed_280` remains the best deployable method by answer quality. The result is especially useful because chunk retrieval still has stronger raw gold-document coverage, yet lower answer quality. This reinforces the paper's distinction between evidence coverage and reader-useful evidence organization.

## Stage-3 Aggregate Source Of Truth

Multi-seed Stage-3 tables should be generated with:

```bash
python scripts/summarize_stage3_results.py <kaggle_results_dir> --out-dir results/stage3_summary_current
```

The summarizer de-duplicates cumulative Kaggle result publishes before computing means and deltas. This avoids over-counting earlier runs that are copied into later `colab_results` folders.

## HotpotQA Qwen 3B Limit-1000 Three-Seed Aggregate

Kaggle Stage-3 HotpotQA validation with `Qwen/Qwen2.5-3B-Instruct`, limit 1000, seeds 42, 7, and 13. These values are generated by the de-duplicated Stage-3 summarizer.

| Policy | Mean Qwen EM | Mean Qwen F1 | Mean Reader Tokens |
| --- | ---: | ---: | ---: |
| chunk_packed_280 | 0.3217 | 0.4232 | 268.99 |
| bm25_packed_280 | 0.2687 | 0.3637 | 268.68 |
| hybrid_packed_280 | 0.2987 | 0.3988 | 268.22 |
| ace_packed_280 | 0.3367 | 0.4358 | 267.30 |
| ace_focused_220 | 0.3320 | 0.4302 | 208.50 |
| router_rule | 0.3307 | 0.4347 | 235.92 |
| router_oracle | 0.4843 | 0.6015 | 221.45 |

Interpretation:

The larger-sample stronger-reader result now supports the same central HotpotQA claim. Packed ACE is the best fixed deployable policy, improving answer quality over packed chunk at essentially the same context budget. Focused ACE gives a strong lower-budget variant. The rule router is now competitive on this larger aggregate, but it still should be framed carefully because its cross-dataset behavior is weaker than the fixed ACE result. The oracle gap remains large, which supports routing as a future direction rather than the main deployed contribution.

## HotpotQA Qwen 3B Budget Curve

Kaggle Stage-3 HotpotQA validation with `Qwen/Qwen2.5-3B-Instruct`, limit 1000. The table below reports the three-seed average for the tighter context budgets.

| Budget Group | Policy | Qwen EM | Qwen F1 | Avg Reader Tokens |
| --- | --- | ---: | ---: | ---: |
| 160 | chunk_packed_160 | 0.2947 | 0.3837 | 150.97 |
| 160 | ace_packed_160 | 0.3160 | 0.4095 | 150.46 |
| 160 | ace_focused_160 | 0.3190 | 0.4144 | 149.62 |
| 220 | chunk_packed_220 | 0.3083 | 0.4058 | 210.52 |
| 220 | ace_packed_220 | 0.3273 | 0.4234 | 209.66 |
| 220 | ace_focused_220 | 0.3320 | 0.4302 | 208.50 |

Interpretation:

The budget curve strengthens the core compression argument. When the reader context budget is tighter, ACE improves answer quality over packed chunk at the same approximate token budget. This now holds across three seeds for both tight-budget settings. The advantage is larger than the standard 280-token comparison, which supports the claim that graph-compressed evidence is most useful under context pressure.

Question-level comparison supports the same pattern most clearly at the tightest budget. This gives the paper a sharper claim: ACE is not just another retrieval variant; it is most useful when the system must fit evidence into a restricted reader context.

## HotpotQA Qwen 3B Extreme Budget Boundary

Kaggle Stage-3 HotpotQA validation with `Qwen/Qwen2.5-3B-Instruct`, limit 1000. This is a replicated stress check over three seeds, not the recommended operating point.

| Budget Group | Policy | Qwen EM | Qwen F1 | Avg Reader Tokens |
| --- | --- | ---: | ---: | ---: |
| 80 | chunk_packed_80 | 0.2333 | 0.3054 | 71.81 |
| 80 | ace_packed_80 | 0.2583 | 0.3404 | 71.70 |
| 80 | ace_focused_80 | 0.2637 | 0.3449 | 71.06 |
| 120 | chunk_packed_120 | 0.2683 | 0.3503 | 111.04 |
| 120 | ace_packed_120 | 0.2880 | 0.3747 | 110.73 |
| 120 | ace_focused_120 | 0.3000 | 0.3883 | 110.05 |

Interpretation:

The boundary check shows that ACE keeps a relative advantage even under severe context pressure, but absolute answer quality drops sharply at very small budgets. This is useful for the paper because it identifies a practical operating range: tight budgets make ACE more valuable, but pushing the context too low still harms the reader. The best paper-facing operating range is therefore the compact budget range, while the extreme-budget table should be used as stress analysis.

## Paired Bootstrap Check

Paired bootstrap checks on the latest HotpotQA Qwen 3B seed compare ACE against chunk on the same questions.

| Setting | Left Policy | Right Policy | Delta F1 | 95% CI |
| --- | --- | --- | ---: | --- |
| budget 80 | ace_focused_80 | chunk_packed_80 | 0.0378 | [0.0130, 0.0637] |
| budget 120 | ace_focused_120 | chunk_packed_120 | 0.0396 | [0.0156, 0.0629] |
| budget 160 | ace_focused_160 | chunk_packed_160 | 0.0398 | [0.0162, 0.0660] |
| budget 220 | ace_focused_220 | chunk_packed_220 | 0.0437 | [0.0212, 0.0677] |
| standard 280 | ace_packed_280 | chunk_packed_280 | 0.0034 | [-0.0218, 0.0299] |

Interpretation:

The paired bootstrap reinforces the budget-pressure finding. On the latest seed, the compact-budget ACE gains are clearly positive, while the standard 280-token comparison is weaker and not separated from zero on that seed. This supports framing the paper around budgeted evidence compression rather than claiming a universal retriever improvement at every context length.
