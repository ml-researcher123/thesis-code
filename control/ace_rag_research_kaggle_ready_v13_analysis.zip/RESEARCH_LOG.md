# ACE-RAG Research Log

Project:

**ACE-RAG: Adaptive Compressed Evidence Graphs for Faithful and Efficient Retrieval-Augmented Generation**

This log records important implementation decisions, experiment outputs, failures, and current interpretations. Dates are in Bangladesh time unless noted otherwise.

## 2026-06-24: Project Scaffold

Created the first ACE-RAG experimental scaffold under:

```text
ace_rag_research/
```

Implemented:

- dataset loaders for `toy`, `hotpotqa`, `musique_local`, and `ragbench`;
- evidence graph construction with passage, claim, and entity nodes;
- edges: `derived_from`, `mentions`, and lightweight `contradicts`;
- chunk retrieval baseline;
- ACE graph retriever;
- compressors: `identity`, `truncate`, `pca`, and `binary`;
- offline extractive answer proxy;
- lightweight verifier;
- metrics for retrieval, answer proxy quality, verifier behavior, and evidence-token budget.

Initial toy smoke test:

| Method | Recall@5 | All-Gold@5 | Avg Evidence Tokens |
| --- | ---: | ---: | ---: |
| Chunk RAG | 1.0000 | 1.0000 | 85.00 |
| ACE Graph | 1.0000 | 1.0000 | 53.25 |

Interpretation:

The local toy run confirmed the pipeline works and showed the expected first signal: ACE graph retrieval can preserve gold-document coverage while reducing retrieved evidence tokens.

## 2026-06-24: Kaggle/Colab Cloud Setup

Created cloud support:

- `requirements-cloud.txt`
- `scripts/cloud_check.py`
- `CLOUD_RUN.md`
- `notebooks/ACE_RAG_Cloud_Quickstart.ipynb`

Initial recommendation:

- Use Kaggle first.
- Prefer T4 x2 over P100 if P100 throws CUDA kernel errors.

Observed error:

```text
CUDA error: no kernel image is available for execution on the device
cudaErrorNoKernelImageForDevice
```

Interpretation:

This was treated as a PyTorch/CUDA/GPU architecture mismatch, most likely from using an incompatible CUDA wheel on Kaggle P100/Pascal. The practical recommendation became: use **Kaggle T4 x2**.

## 2026-06-24: First HotpotQA Limit 200 Run

Configuration:

```text
dataset: hotpotqa
limit: 200
embedding: BAAI/bge-small-en-v1.5
compressor: pca:128
top_k_nodes: 12
max_expanded_docs: 5
```

Output:

| Method | Recall@5 | All-Gold@5 | Extractive F1 | Avg Evidence Tokens |
| --- | ---: | ---: | ---: | ---: |
| Chunk RAG | 0.8525 | 0.7100 | 0.0475 | 402.20 |
| ACE Graph, PCA128 | 0.7950 | 0.6550 | 0.0715 | 135.71 |

Interpretation:

ACE achieved much lower token cost but lost too much retrieval quality under PCA128. This suggested:

- graph evidence allocation is promising;
- PCA compression is too lossy at 128 dimensions;
- identity/no-compression ACE should be tested next.

## 2026-06-24: HotpotQA Limit 200 Identity and PCA256

Identity result:

| Method | Recall@5 | All-Gold@5 | Extractive F1 | Avg Evidence Tokens |
| --- | ---: | ---: | ---: | ---: |
| Chunk RAG | 0.8525 | 0.7100 | 0.0475 | 402.20 |
| ACE Graph, Identity | 0.8375 | 0.7000 | 0.0721 | 135.97 |

PCA256 result:

| Method | Recall@5 | All-Gold@5 | Extractive F1 | Avg Evidence Tokens |
| --- | ---: | ---: | ---: | ---: |
| ACE Graph, PCA256 | 0.8225 | 0.6750 | 0.0689 | 240.26 |

Interpretation:

The strongest early signal came from ACE identity:

- only -1.5 recall@5 points versus chunk RAG;
- only -1.0 all_gold@5 point;
- about 66% fewer evidence tokens;
- higher extractive F1 proxy.

PCA256 improved over PCA128 but still degraded retrieval and used more evidence tokens.

## 2026-06-24/25: HotpotQA Limit 1000

Chunk baseline:

| Method | Recall@5 | All-Gold@5 | Extractive F1 | Avg Evidence Tokens |
| --- | ---: | ---: | ---: | ---: |
| Chunk RAG | 0.8560 | 0.7230 | 0.0499 | 408.94 |

ACE identity, `top_k_nodes=48`, `max_expanded_docs=5`:

| Method | Recall@5 | All-Gold@5 | Extractive F1 | Avg Evidence Tokens |
| --- | ---: | ---: | ---: | ---: |
| ACE Graph, Identity | 0.8310 | 0.6840 | 0.0845 | 136.63 |

Interpretation:

This is the current strongest Stage-1 result:

- ACE uses about 66.6% fewer evidence tokens than chunk RAG;
- recall@5 drops by 2.5 points;
- all_gold@5 drops by 3.9 points;
- extractive F1 proxy improves from 0.0499 to 0.0845.

Research claim supported so far:

> ACE graph retrieval preserves most HotpotQA evidence coverage while using about one-third of the evidence tokens.

## 2026-06-25: Runtime Optimization

Observed Kaggle behavior:

```text
GPU usage: near 0%
CPU usage: high
```

Interpretation:

The run was not purely GPU-bound. The heavy stages were:

- evidence graph construction;
- Python graph traversal;
- ranking over many graph nodes;
- repeated methods in the same command;
- saving large run JSONs.

Implemented optimizations:

- explicit `--device cuda`;
- progress markers:
  - `[ace] building evidence graph`
  - `[ace] fitting/indexing embeddings`
  - `[embed] encoding ... on device=cuda`
  - `[ace] retrieving`
- `--methods ace_graph` to avoid rerunning chunk/no-conflict variants;
- `--no-save-runs` to skip large JSON output during tuning;
- batched query embedding;
- top-k selection with `argpartition` instead of full sorting.

Created:

- `notebooks/ACE_RAG_Kaggle_Runbook.ipynb`
- `ace_rag_research_kaggle_ready_v2.zip`

Important packaging issue:

The first Kaggle zip used Windows-style backslashes in archive names and Kaggle rejected it:

```text
contains a forbidden character in name ('\')
```

Fixed by creating `ace_rag_research_kaggle_ready_v2.zip` with POSIX `/` archive paths.

## 2026-06-25: Budget Tuning, Docs 6

Configuration:

```text
limit: 1000
compressor: identity
top_k_nodes: 48
max_expanded_docs: 6
methods: ace_graph
device: cuda
no_save_runs: true
```

Output:

| Method | Recall@5 | All-Gold@5 | Extractive F1 | Avg Evidence Tokens |
| --- | ---: | ---: | ---: | ---: |
| ACE Graph, Identity, docs=6 | 0.8310 | 0.6840 | 0.0861 | 166.25 |

Comparison to docs=5:

| Config | Recall@5 | All-Gold@5 | Extractive F1 | Avg Evidence Tokens |
| --- | ---: | ---: | ---: | ---: |
| docs=5 | 0.8310 | 0.6840 | 0.0845 | 136.63 |
| docs=6 | 0.8310 | 0.6840 | 0.0861 | 166.25 |

Interpretation:

Increasing `max_expanded_docs` from 5 to 6 did not improve retrieval coverage. It increased tokens by about 30 and gave only a tiny extractive F1 gain. Current best budget remains `max_expanded_docs=5`.

## 2026-06-25: Candidate Tuning, Nodes 64

Configuration:

```text
limit: 1000
compressor: identity
top_k_nodes: 64
max_expanded_docs: 5
methods: ace_graph
device: cuda
no_save_runs: true
```

Output:

| Method | Recall@5 | All-Gold@5 | Extractive F1 | Avg Evidence Tokens | Avg Hits |
| --- | ---: | ---: | ---: | ---: | ---: |
| ACE Graph, Identity, nodes=64 | 0.8310 | 0.6840 | 0.0845 | 136.68 | 9.25 |

Comparison to nodes=48:

| Config | Recall@5 | All-Gold@5 | Avg Evidence Tokens | Avg Hits |
| --- | ---: | ---: | ---: | ---: |
| nodes=48 | 0.8310 | 0.6840 | 136.63 | 9.25 |
| nodes=64 | 0.8310 | 0.6840 | 136.68 | 9.25 |

Interpretation:

Increasing `top_k_nodes` from 48 to 64 did not improve retrieval. The run appears dominated by early document expansion and `max_expanded_docs=5`, not by candidate-node scarcity.

## 2026-06-25: Truncation Compression, 384 Dimensions

Configuration:

```text
limit: 1000
compressor: truncate
compress_dims: 384
top_k_nodes: 48
max_expanded_docs: 5
methods: ace_graph
device: cuda
no_save_runs: true
```

Output:

| Method | Recall@5 | All-Gold@5 | Extractive F1 | Avg Evidence Tokens |
| --- | ---: | ---: | ---: | ---: |
| ACE Graph, Truncate384 | 0.8310 | 0.6840 | 0.0845 | 136.68 |

Interpretation:

`truncate:384` matches identity. Since `BAAI/bge-small-en-v1.5` has 384-dimensional embeddings, this is effectively a no-op check. It confirms that the truncation path is functioning and does not alter results at full dimension.

Next important compression tests:

```text
truncate:256
truncate:128
```

Target:

- `truncate:256` should preserve most identity performance:
  - recall@5 >= 0.825
  - all_gold@5 >= 0.675
- `truncate:128` can drop more, but should ideally stay near recall@5 >= 0.80.

## 2026-06-25: Truncation Compression, 256 Dimensions

Configuration:

```text
limit: 1000
compressor: truncate
compress_dims: 256
top_k_nodes: 48
max_expanded_docs: 5
methods: ace_graph
device: cuda
no_save_runs: true
```

Output:

| Method | Recall@5 | All-Gold@5 | Extractive F1 | Avg Evidence Tokens | Avg Hits |
| --- | ---: | ---: | ---: | ---: | ---: |
| ACE Graph, Truncate256 | 0.8165 | 0.6610 | 0.0826 | 136.29 | 9.08 |

Comparison:

| Config | Recall@5 | All-Gold@5 | Extractive F1 | Avg Evidence Tokens |
| --- | ---: | ---: | ---: | ---: |
| Identity / full 384 dims | 0.8310 | 0.6840 | 0.0845 | 136.63 |
| Truncate256 | 0.8165 | 0.6610 | 0.0826 | 136.29 |

Interpretation:

`truncate:256` gives 33% smaller dense vectors but loses:

- 1.45 recall@5 points versus identity;
- 2.3 all_gold@5 points versus identity;
- slight extractive F1.

This is not catastrophic, but it is weaker than the target threshold. For the current HotpotQA setup, naive 256-dimensional truncation loses more evidence coverage than desired.

Next useful compression test:

```text
truncate:320
```

This tests whether a smaller 16.7% compression retains identity-level retrieval better than 256.

## Current Best Result

Best Stage-1 config:

```text
dataset: HotpotQA
limit: 1000
model: BAAI/bge-small-en-v1.5
method: ACE Graph
compressor: identity
top_k_nodes: 48
max_expanded_docs: 5
```

Best Stage-1 comparison:

| Method | Recall@5 | All-Gold@5 | Extractive F1 | Avg Evidence Tokens |
| --- | ---: | ---: | ---: | ---: |
| Chunk RAG | 0.8560 | 0.7230 | 0.0499 | 408.94 |
| ACE Graph | 0.8310 | 0.6840 | 0.0845 | 136.63 |

Current claim:

> On a 1000-example HotpotQA slice, ACE graph retrieval keeps most of chunk RAG's evidence coverage while reducing evidence-token budget by about two-thirds and improving a simple extractive answer proxy.

Current caveats:

- The answer generator is still an extractive proxy, not a real LLM generator.
- The verifier is heuristic, not an NLI/LLM verifier.
- PCA compression underperforms.
- Conflict expansion does not matter on HotpotQA because it is not a conflict-heavy dataset.
- We still need MuSiQue, RAGBench, and a conflict benchmark before this becomes paper-grade evidence.

## 2026-06-25: Qwen Reader Context Experiments

The first local Qwen reader experiments showed that raw graph hits were too fragmentary for answer generation. Feeding full source passages improved answer quality but removed much of ACE-RAG's efficiency advantage. A snippet-based reader context recovered most of the source-passage answer quality while reducing the reader context, but the token savings were still not strong enough for a clean final claim.

Interpretation:

ACE-RAG's retrieval stage is promising, but the generation stage needs a better evidence materialization policy. The next direction is to tune snippet selection and budget rather than simply switching to a larger reader model.

## 2026-06-25: Autonomous Stage-2 Pipeline

Built a Kaggle-oriented autonomous Stage-2 runner. It retrieves chunk and ACE evidence once, loads the local Qwen reader once, and evaluates multiple source and packed-snippet reader policies in one job. This should replace manual snippet sweeps and give a cleaner comparison of evidence packing strategies.

## 2026-06-25: Packed Evidence Becomes Promising

The autonomous Stage-2 run showed that budget-aware packed snippets are meaningfully better than naive snippets. The best ACE packed policy came close to the full chunk-source reader while using much less reader context. It also outperformed the packed chunk control at a similar budget.

Interpretation:

This is the strongest generation-stage signal so far. The research direction should now shift from ad hoc snippet tuning to scaling and validating packed evidence. The next question is whether the packed-evidence result holds on a larger HotpotQA slice and then on a harder multi-hop dataset.

## 2026-06-25: Packed Evidence Scaling Check

The larger HotpotQA check showed that packed snippets remain useful for reducing reader context, but the advantage of ACE packed snippets over the packed chunk control did not hold. This weakens the generation-stage claim in its current form.

Interpretation:

The graph retrieval layer is still promising for evidence selection, but the packed reader evidence needs a stronger selection policy. The next method step should be a better evidence packer or reranker, not simply scaling the same packed-snippet policy.

## 2026-06-25: Focused Evidence Packing

Implemented a bounded improvement to evidence packing. The new focused packer keeps the same retrieval pipeline but prefers snippets that add new question-term coverage and cover distinct retrieved documents under a fixed budget. This is a single method improvement for comparison against the previous packed-snippet policy, not a broad search over new mechanisms.

The focused packer improved the ACE generation result on the larger HotpotQA slice. The lower focused budget was better than the larger one, suggesting that better evidence selection matters more than simply adding more context. This is now the strongest ACE generation-stage method, though the packed chunk control remains a serious baseline.

## 2026-06-25: Stage-2 Limit-1000 Validation

The larger HotpotQA run produced the strongest generation-stage result so far. ACE with packed evidence outperformed the chunk-source reader and the packed chunk control while using much less context than full chunk sources. This gives the project its first credible end-to-end RAG signal, not just a retrieval-efficiency signal.

Interpretation:

The best current story is no longer focused packing. The strongest policy is ACE graph retrieval followed by packed snippet evidence at the moderate budget. This should now be validated on a different HotpotQA slice before moving to a new dataset.

## 2026-06-25: HotpotQA Seed Validation

The reported seed-validation run preserved the same overall pattern as the main HotpotQA Stage-2 run. ACE graph retrieval with packed evidence remained the strongest end-to-end policy among the tested settings, while using less reader context than full chunk sources.

Interpretation:

This strengthens the HotpotQA result. The next validation should move to MuSiQue rather than continuing to tune HotpotQA.

## 2026-06-25: MuSiQue Stress Test

MuSiQue is substantially harder for both chunk and ACE retrieval. The first MuSiQue Stage-2 run showed that ACE retrieval still reduces context, but evidence coverage is weaker and the HotpotQA advantage does not transfer cleanly. The focused packed variant was the best ACE generation policy on the first MuSiQue slice, but the result should be treated as a stress-test signal rather than a confirmed win.

Interpretation:

The project now has a clear split: HotpotQA supports the ACE packed-evidence story, while MuSiQue exposes the need for stronger multi-hop retrieval expansion. The next MuSiQue step should be a bounded retrieval-expansion test rather than more reader-context tuning.

## 2026-06-25: MuSiQue Expansion Test

The bounded MuSiQue expansion test did not help. Increasing ACE's graph-node and expanded-document budget increased reader context but did not improve evidence coverage or answer quality. This suggests the current MuSiQue bottleneck is not simply insufficient expansion depth.

Interpretation:

Stop MuSiQue tuning for this method version. Treat MuSiQue as evidence that harder composed multi-hop QA requires better graph construction or reasoning-aware retrieval, not just more retrieved context.

## 2026-06-25: Bridge-Aware ACE Retrieval

Implemented a bounded bridge-aware ACE retriever for MuSiQue-style composed questions. It performs first-hop graph retrieval, extracts bridge terms from the first-hop evidence, and uses those terms for a second-hop graph reranking pass. This tests one clear hypothesis: MuSiQue needs better bridge evidence discovery, not just more retrieval expansion.

The MuSiQue bridge run produced a modest positive result. Bridge-aware ACE improved evidence coverage compared with standard ACE and gave the strongest MuSiQue Qwen result so far, though the absolute answer quality remains low. This supports bridge-aware retrieval as a useful direction, but MuSiQue is still a hard stress test rather than a clean win.

## 2026-06-25: MuSiQue Bridge Validation

The larger MuSiQue bridge validation preserved the same weak-positive pattern. Bridge-aware ACE with packed evidence outperformed the chunk baselines on the Qwen answer metric while using less context than full chunk sources, even though its retrieval coverage remained lower than chunk retrieval.

Interpretation:

This is enough MuSiQue evidence for the current phase. The right framing is that bridge-aware ACE improves the method's behavior on a harder dataset, but MuSiQue remains a stress test with low absolute answer quality. Stop experiments here and consolidate the thesis.

## Baseline Expansion

Added standard lexical retrieval and dense plus lexical hybrid retrieval baselines. Future answer-generation tables can now compare ACE against stronger retrieval controls in the same run, which is necessary before making any publication-level claim.

## Baseline Validation Finding

The stronger baseline run changed the HotpotQA story. ACE with packed evidence beats the packed chunk and packed hybrid controls under a similar context budget, but it does not beat full source chunk reading. The thesis claim should focus on budget-constrained answer quality and evidence efficiency, not absolute best accuracy.

## MuSiQue Baseline Validation Finding

The stronger MuSiQue baseline run is a meaningful positive result. Bridge-aware ACE with packed evidence produced the best answer-quality result among the tested chunk, lexical, hybrid, and ACE policies while keeping the reader context compact. The retrieval problem is still not fully solved, so this should be framed as better budgeted generation on a hard stress test rather than a complete MuSiQue solution.

## HotpotQA Robustness Check

The second HotpotQA seed weakened the earlier clean win. ACE with packed evidence remained competitive and beat the lexical and hybrid packed controls, but it did not beat packed chunk retrieval on this slice. The HotpotQA claim should now be framed as mixed but promising budgeted evidence compression, not a stable superiority claim over packed chunk RAG.

## Additional HotpotQA Robustness Check

Another HotpotQA seed showed the same mixed pattern. ACE remained stronger than the lexical and hybrid packed controls, and the focused ACE setting used much less context than packed chunk, but fixed ACE still did not consistently beat packed chunk retrieval. This supports moving to an adaptive router instead of continuing fixed-policy tuning.

## Adaptive Router Implementation

Implemented a Stage-3 adaptive evidence router. It compares compact fixed policies, a simple retrieval-feature router, and an oracle router upper bound in one run. The purpose is to test whether choosing evidence strategy per question can overcome the weakness of fixed ACE policies.

## Adaptive Router Validation Finding

The first adaptive-router validation produced the right diagnostic but not yet a deployable router result. The oracle router showed that different questions really do prefer different compact evidence policies, so routing is worth pursuing. The hand-written rule router failed because it selected focused ACE too often, which confirmed that fixed heuristics are too brittle for the final thesis claim.

Follow-up implementation:

The Qwen reader now uses decoder-safe left padding. The rule router is now conservative and only chooses ACE when its retrieval signal is clearly stronger than chunk retrieval. Stage-3 also writes a per-question router feature file so the next routing step can be learned or calibrated from observed policy behavior instead of guessed manually.

## Corrected Stage-3 Reader Finding

The corrected Qwen reader changed the HotpotQA interpretation. Once decoder padding was fixed, focused ACE became the strongest compact fixed policy, and the conservative router became competitive with it. This makes the adaptive compressed-evidence direction stronger, but it still needs robustness checks across seeds and datasets before it can support a serious publication claim.

## Corrected HotpotQA Robustness Finding

The corrected reader result held up on another HotpotQA seed. ACE with compact packed evidence remained stronger than the compact baselines on answer quality, while the focused variant preserved the lower-context advantage. The rule router remained competitive but did not consistently beat the best fixed ACE policy. The next method work should therefore focus on learned or calibrated routing, not more manual routing rules.

## Offline Router Transfer Finding

The first learned-router transfer check did not produce a deployable router improvement. With the current retrieval-confidence features, the learned router mostly collapses toward focused ACE and does not reliably beat the best fixed compact ACE policy. This is useful evidence: the oracle gap is real, but closing it needs better deploy-time signals such as question decomposition, answerability confidence, policy agreement, or stronger graph-specific uncertainty features.

## Three-Seed Corrected HotpotQA Finding

The corrected HotpotQA result now holds across multiple sampled seeds. The rule router has the best average answer quality among deployable policies, while focused ACE remains the strongest compact fixed-policy option. This materially strengthens the thesis: the method is no longer just a single-run positive result. The remaining gap is cross-dataset validation and a stronger explanation of why compact graph evidence improves answer quality despite lower raw retrieval coverage than chunk retrieval.

## Corrected MuSiQue Stage-3 Finding

The corrected MuSiQue router run finished cleanly. Bridge-aware ACE remained the strongest fixed compact policy on answer quality, but the hand-written router was not strong enough on this harder dataset because it routed too often to chunk-style evidence. A small offline threshold sweep did not give a robust rule change across HotpotQA and MuSiQue, so the right next step is not more manual router tuning. The next bounded validation is to keep retrieval and routing fixed and test whether the MuSiQue finding holds with a stronger free Qwen reader.

## Qwen Three-Billion HotpotQA Validation

The first stronger-reader Kaggle run completed through the GitHub result loop. On HotpotQA, ACE packed became the best deployable policy, while focused ACE stayed very close with a substantially smaller evidence budget. This strengthens the central thesis claim because the ACE advantage is not only an artifact of the smaller Qwen reader. The rule router still underperformed the best fixed ACE option, so the current paper should emphasize compact graph evidence first and adaptive routing as a promising but unfinished extension.

## Qwen Three-Billion HotpotQA Robustness

The stronger-reader result replicated across additional HotpotQA samples. Across the completed Qwen three-billion runs, fixed ACE with packed evidence has the best average deployable answer quality, and focused ACE is nearly tied while using much less context. The router still does not consistently beat fixed ACE, but the oracle remains far higher, so routing should be presented as future method headroom rather than the main finished contribution.

## Qwen Three-Billion HotpotQA Scaling

The first larger Qwen three-billion HotpotQA run completed successfully. At the larger sample size, fixed ACE packed evidence remained stronger than packed chunk retrieval on answer quality, while the focused lower-budget ACE setting became more of an efficiency tradeoff than a near-tie. This is an important refinement: the headline method should be ACE packed evidence for quality, with focused ACE as the compact variant.

## Qwen Three-Billion HotpotQA Scaling Robustness

The second larger HotpotQA run replicated the fixed ACE packed result. Across the larger Qwen three-billion samples completed so far, ACE packed has the best deployable answer quality, while focused ACE remains the compact variant. This is now strong enough to treat larger-reader HotpotQA as a core positive result, pending the final larger-sample seed.

## Next Runs

Run next:

```bash
python -m experiments.run_mvp \
  --config configs/hotpotqa.yaml \
  --limit 1000 \
  --compressor truncate \
  --compress-dims 320 \
  --top-k-nodes 48 \
  --max-expanded-docs 5 \
  --methods ace_graph \
  --device cuda \
  --no-save-runs \
  --out-dir cloud_results
```

Then:

```bash
python -m experiments.run_mvp \
  --config configs/hotpotqa.yaml \
  --limit 1000 \
  --compressor truncate \
  --compress-dims 128 \
  --top-k-nodes 48 \
  --max-expanded-docs 5 \
  --methods ace_graph \
  --device cuda \
  --no-save-runs \
  --out-dir cloud_results
```

## Kaggle Automation And Analysis Hygiene

Added a safer Kaggle GitHub publishing path and a de-duplicated Stage-3 summarizer. This matters because Kaggle result folders are cumulative, so repeated files can otherwise make aggregate results look stronger or weaker than they really are. The thesis evidence should be based on logical runs, not repeated copies from later result publishes.

## Larger HotpotQA Validation Completed

The stronger Qwen reader has now completed the larger HotpotQA validation across the planned seeds. The result supports the main fixed packed ACE claim and makes the HotpotQA side of the thesis substantially more stable. Routing remains useful as evidence of headroom, but fixed packed ACE is still the cleanest headline method.

## Question-Level Error Analysis Added

Added a script for comparing Stage-3 policies question by question. This gives the paper a way to discuss where ACE helps and where chunk retrieval still wins, instead of relying only on aggregate scores.

## Budget Curve Pilot

The tighter-budget HotpotQA result is now replicated across the planned seeds. Both compact budgets support the context-pressure hypothesis, with the tightest budget showing the cleanest advantage. This is one of the strongest paper-facing results so far.

## Extreme Budget Boundary Check

The very-small-budget result is now replicated across the planned seeds. ACE still has a relative advantage when context is aggressively restricted, but absolute answer quality falls sharply. This should be treated as boundary analysis rather than a recommended deployment setting.

## Paired Bootstrap Check

Added paired bootstrap analysis over saved predictions. The check supports the budget-pressure framing: compact-budget comparisons separate more clearly from chunk retrieval than the standard-budget comparison.

## Cross-Dataset Validation Step

Moved the pipeline from HotpotQA budget sweeps to cross-dataset validation. The next Kaggle control job prefers MuSiQue when the dataset is mounted, and otherwise tries a small RAGBench validation run. This is meant to test whether the budgeted ACE finding transfers beyond HotpotQA.

## Budget Summary Grouping Fix

Updated the summarizer so budget-curve runs are grouped separately from the standard runs. This avoids mixing policies that happen to share the same name but come from different evidence-budget experiments.
